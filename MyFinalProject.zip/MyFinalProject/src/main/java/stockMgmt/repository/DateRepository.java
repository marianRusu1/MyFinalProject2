package stockMgmt.repository;

//import org.springframework.data.jpa.repository.JpaRepository;
//import stockMgmt.entity.DueDate;
//
//public interface DateRepository extends JpaRepository<DueDate, Long> {
//
//}

