package stockMgmt.rest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import stockMgmt.entity.Dealer;
import stockMgmt.entity.Invoice;
//import stockMgmt.repository.DateRepository;
import stockMgmt.repository.DealerRepository;
import stockMgmt.repository.InvoiceRepository;
import stockMgmt.repository.ItemRepository;

@NoRepositoryBean
@RestController
public class InvoiceController {

    @Autowired
    private InvoiceRepository invoiceRepository;

    @Autowired
    private DealerRepository dealerRepository;

//    @Autowired
//    private DateRepository dateRepository;

    @Autowired
    private ItemRepository itemRepository;

    @PostMapping(value = "/invoice")
    public void saveInvoice(@RequestBody Invoice invoice) {
        final Dealer dealer = dealerRepository.findByName(invoice.getDealer().getName());
        if (dealer != null) {
            invoice.setDealer(dealer);
        }
        else {
            invoice.setDealer(dealerRepository.save(invoice.getDealer()));
        }
        //dealerRepository.save(invoice.getDealer());
        itemRepository.saveAll(invoice.getItems());
        invoiceRepository.save(invoice);

    //@GetMapping(value = "/invoice/number/{invoiceNo}")

    }
}
