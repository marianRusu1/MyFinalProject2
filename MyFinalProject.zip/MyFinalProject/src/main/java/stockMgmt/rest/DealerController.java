package stockMgmt.rest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import stockMgmt.entity.Dealer;
import stockMgmt.repository.DealerRepository;
import java.util.List;



@RestController
public class DealerController {

    @Autowired
    DealerRepository dealerRepository;

    @GetMapping(value = "/dealer/all")
    public List<Dealer> getAllDealers() {
        return dealerRepository.findAll();
    }

    @PostMapping(value = "/dealer/create")
    public void saveDealer(@RequestBody Dealer dealer) {
        dealerRepository.save(dealer);
    }

    @DeleteMapping(value = "/dealer/delete/all")
    public void deleteAllDealer(@PathVariable List<Dealer> dealers) {
        dealerRepository.deleteAll(getAllDealers());
        }
    }


