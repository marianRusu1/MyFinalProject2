package stockMgmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import stockMgmt.entity.DueDate;

import java.util.Date;


@SpringBootApplication
    public class App {

        public static void main(String[] args) {

            SpringApplication.run(App.class, args);
            //System.out.println("Data curenta este: " + DueDate.issueDate);
    }


}
