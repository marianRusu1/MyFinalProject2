package stockMgmt.entity;

public enum BudgetArticle {

   Equipments, Accessories, Service, Parts, Investments

   }
